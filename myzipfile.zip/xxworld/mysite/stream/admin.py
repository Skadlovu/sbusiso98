from django.contrib import admin
from. models import LiveStream, Video


admin.site.register(LiveStream)
admin.site.register(Video)


# Register your models here.
